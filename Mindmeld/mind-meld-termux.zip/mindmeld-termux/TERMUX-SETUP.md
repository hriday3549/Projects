# Mind Meld — running the Host server on your Android phone

This turns your phone into the Host: it runs the exact same
`server.js` used on desktop/the `.exe`, unmodified, via
[Termux](https://termux.dev) — a real terminal/Linux environment for
Android. Nothing here is Android-specific hacks; Node.js just runs
like it would on any Linux machine.

**Android only.** iOS does not allow apps to run a persistent
background server without a full native build shipped through
Xcode/App Store — there's no "just run a file" equivalent on iPhone.

## 1. Install Termux (not from the Play Store)

The Play Store version of Termux is outdated and no longer maintained.
Use one of:
- [F-Droid](https://f-droid.org/packages/com.termux/) (recommended), or
- the [GitHub releases page](https://github.com/termux/termux-app/releases)

Install and open it once so it finishes its first-run setup.

## 2. Get this folder onto your phone

Get the `mindmeld-termux` folder (or the zip containing it) onto your
phone any way that's convenient — airdrop/nearby share, a cloud drive
sync, USB transfer, or emailing it to yourself — so it ends up
somewhere like your **Downloads** folder.

## 3. Give Termux access to your files

In Termux, run:

```
termux-setup-storage
```

Android will show a permission prompt — allow it. This lets Termux see
your phone's normal storage (Downloads, etc.), not just its own
sandboxed folder.

## 4. Copy the project into Termux and run it

```
cp -r /sdcard/Download/mindmeld-termux ~/mindmeld
cd ~/mindmeld
bash start.sh
```

(Adjust the path in the first line if you saved the folder somewhere
other than Downloads.)

The first run will take a minute or two — `start.sh` installs Node.js
itself via Termux's package manager, then installs the three small
dependencies (`express`, `ws`, `qrcode`), then starts the server. Every
run after that is instant.

You'll see the same startup message as on desktop:

```
  Mind Meld — LAN server running (HTTPS)
  ------------------------------------
  On this device, open:  https://localhost:3000
  Other players on the same Wi-Fi, open:
    https://192.168.1.42:3000
```

Open that `localhost` link in your phone's browser — you're the Host
and a player, same as before. Your browser will show a "connection
isn't private" warning the first time — that's expected (see the
HTTPS note below), tap through it. Everyone else on the same Wi-Fi
scans the QR code on your Lobby screen, or taps **Copy join link** and
shares it however's easiest, or opens the printed IP.

### About the HTTPS warning

The server runs HTTPS by default with a private, self-signed
certificate — there's no real domain name to get a properly-signed
one for a LAN game. Every device's browser will show a security
warning on first visit (something like "connection isn't private" /
"proceed to site"); this is expected for any self-signed cert, not a
sign anything's wrong. Tap through it once per device.

If that warning is more friction than you want for a casual game,
restart the server in plain-HTTP mode instead:

```
MIND_MELD_HTTP=1 bash start.sh
```

## Keeping it running mid-game

Android aggressively kills background processes to save battery,
including Termux, once the screen locks or you switch apps. For a
short round or two with the screen on, you won't notice this. To be
safe for a longer game:

- **Keep Termux in the foreground** and don't let the screen lock —
  easiest is to just prop the phone up and leave Termux open as the
  "TV" everyone glances at, same as a laptop screen would be.
- **Or install the separate Termux:API app** (same F-Droid/GitHub
  source as Termux itself) plus its Termux package
  (`pkg install termux-api`). `start.sh` detects it automatically and
  grabs a wake lock, which stops Android from suspending the server
  when the screen locks.

## Stopping the server

`Ctrl+C` in Termux (or just close the Termux session).

## Notes

- This is the *same* `server.js`/`public/` as the desktop project —
  no code changes were needed to run it on Android. The UDP discovery
  beacon and QR-code join flow work exactly as documented in the main
  README.
- Some phone Wi-Fi settings (especially "AP isolation" on guest
  networks, or certain carrier-provided hotspots) block devices on the
  same network from reaching each other. If players can't connect,
  that's the first thing to check — try a home Wi-Fi network instead
  of a hotspot if you hit this.
