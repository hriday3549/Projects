'use strict';

/**
 * MIND MELD — LAN Edition
 * ------------------------
 * Listen-server architecture: this ONE process is both the game server
 * (authoritative state) and hosts the Host player's own browser tab as
 * just another WebSocket client. Up to 7 more players join over Wi-Fi
 * from their own devices' browsers — nothing to install.
 *
 * Transport:
 *   - HTTP (express)   serves the client web app + a small REST API
 *   - WebSocket (ws)   real-time game state sync (the "TCP sockets")
 *   - UDP broadcast    (dgram) genuine LAN discovery beacon. Browsers
 *                       can't listen for raw UDP, so the web client
 *                       actually joins via a QR code / IP the Host
 *                       displays. The UDP beacon is real and is there
 *                       for any native/CLI client (see discover.js) —
 *                       documented in README.md.
 */

const http = require('http');
const https = require('https');
const path = require('path');
const os = require('os');
const dgram = require('dgram');
const crypto = require('crypto');
const express = require('express');
const { WebSocketServer } = require('ws');
const QRCode = require('qrcode');
const selfsigned = require('selfsigned');

const PORT = process.env.PORT ? Number(process.env.PORT) : 3000;
const UDP_DISCOVERY_PORT = 41234;
const GAME_NAME = 'Mind Meld';
const MAX_PLAYERS = 8;
const MIN_PLAYERS_TO_START = 2;
// HTTPS is on by default (self-signed cert — see generateSelfSignedCert
// below). Set MIND_MELD_HTTP=1 to fall back to plain HTTP if a device on
// your network can't get past the certificate warning.
const USE_HTTPS = process.env.MIND_MELD_HTTP !== '1';
let activeScheme = 'http'; // updated once the server actually starts

// ---------------------------------------------------------------------------
// Game state (single room — this process IS one party's host)
// ---------------------------------------------------------------------------

/** @type {Map<import('ws').WebSocket, Player>} */
const players = new Map();

/**
 * @typedef {Object} Player
 * @property {string} id
 * @property {string} name
 * @property {boolean} isHost
 * @property {'typing'|'ready'} status
 * @property {string|null} word
 */

let state = 'LOBBY'; // LOBBY | INPUT | REVEAL | GAMEOVER
let round = 1;
let roundHistory = []; // [{ round, words: [{id,name,word}] }]

function publicPlayerList() {
  return [...players.values()].map((p) => ({
    id: p.id,
    name: p.name,
    isHost: p.isHost,
    status: state === 'LOBBY' ? undefined : p.status,
  }));
}

function broadcast(type, payload) {
  const msg = JSON.stringify({ type, ...payload });
  for (const ws of players.keys()) {
    if (ws.readyState === ws.OPEN) ws.send(msg);
  }
}

function send(ws, type, payload) {
  if (ws.readyState === ws.OPEN) ws.send(JSON.stringify({ type, ...payload }));
}

function broadcastLobby() {
  broadcast('LOBBY_UPDATE', {
    players: publicPlayerList(),
    canStart: players.size >= MIN_PLAYERS_TO_START,
    minPlayers: MIN_PLAYERS_TO_START,
    maxPlayers: MAX_PLAYERS,
  });
}

function broadcastStatus() {
  broadcast('STATUS_UPDATE', { round, players: publicPlayerList() });
}

function startRound() {
  state = 'INPUT';
  for (const p of players.values()) {
    p.word = null;
    p.status = 'typing';
  }
  const last = roundHistory[roundHistory.length - 1];
  const previousWords = last ? last.words.map((w) => w.word) : [];
  broadcast('ROUND_START', { round, players: publicPlayerList(), previousWords });
}

function normalizeWord(w) {
  return String(w || '').trim().toLowerCase().replace(/\s+/g, ' ');
}

function maybeReveal() {
  const all = [...players.values()];
  if (all.length === 0) return;
  const allReady = all.every((p) => p.status === 'ready');
  if (!allReady) return;

  const words = all.map((p) => ({ id: p.id, name: p.name, word: p.word }));
  const normalized = words.map((w) => normalizeWord(w.word));
  const isMeld = normalized.every((w) => w === normalized[0]) && normalized[0] !== '';

  roundHistory.push({ round, words });
  state = 'REVEAL';

  broadcast('REVEAL', { round, words, isMeld });

  if (isMeld) {
    state = 'GAMEOVER';
    broadcast('GAME_OVER', { round, words });
  }
}

function promoteNewHost() {
  const next = [...players.values()][0];
  if (next) {
    next.isHost = true;
    return next;
  }
  return null;
}

function resetToLobby() {
  state = 'LOBBY';
  round = 1;
  roundHistory = [];
  for (const p of players.values()) {
    p.word = null;
    p.status = 'typing';
  }
  broadcastLobby();
}

// ---------------------------------------------------------------------------
// HTTP + static app
// ---------------------------------------------------------------------------

const app = express();
app.use(express.static(path.join(__dirname, 'public')));
app.use(express.json());

function getLanAddresses() {
  const nets = os.networkInterfaces();
  const addrs = [];
  for (const name of Object.keys(nets)) {
    for (const net of nets[name] || []) {
      if (net.family === 'IPv4' && !net.internal) addrs.push(net.address);
    }
  }
  return addrs;
}

/**
 * Generates a fresh self-signed TLS certificate covering localhost,
 * 127.0.0.1, and every LAN IP currently detected on this machine, so
 * whichever address a player uses to connect matches the cert.
 *
 * This is a *private* certificate with no real Certificate Authority
 * behind it (there's no public DNS name to get a CA-signed cert for on
 * a LAN game) — every browser will show a "connection is not private"
 * warning on first visit. That's expected, not a bug: click
 * Advanced -> Proceed once per device, same as any self-signed cert.
 */
async function generateSelfSignedCert(addresses) {
  const altNames = [
    { type: 2, value: 'localhost' }, // DNS
    { type: 7, ip: '127.0.0.1' }, // IP
    ...addresses.map((ip) => ({ type: 7, ip })),
  ];
  const attrs = [{ name: 'commonName', value: addresses[0] || 'localhost' }];
  const pems = await selfsigned.generate(attrs, {
    days: 825,
    keySize: 2048,
    algorithm: 'sha256',
    extensions: [{ name: 'subjectAltName', altNames }],
  });
  return { key: pems.private, cert: pems.cert };
}

app.get('/api/host-info', async (req, res) => {
  const addrs = getLanAddresses();
  const primary = addrs[0] || 'localhost';
  const url = `${activeScheme}://${primary}:${PORT}/`;
  let qrDataUrl = null;
  try {
    qrDataUrl = await QRCode.toDataURL(url, { margin: 1, scale: 6, color: { dark: '#14121f', light: '#00000000' } });
  } catch (e) {
    qrDataUrl = null;
  }
  res.json({ name: GAME_NAME, port: PORT, scheme: activeScheme, addresses: addrs, url, qrDataUrl });
});

async function startServer() {
  let server;
  if (USE_HTTPS) {
    try {
      const { key, cert } = await generateSelfSignedCert(getLanAddresses());
      server = https.createServer({ key, cert }, app);
      activeScheme = 'https';
    } catch (err) {
      console.warn(`[https] Could not generate a certificate (${err.message}) — falling back to plain HTTP.`);
      server = http.createServer(app);
      activeScheme = 'http';
    }
  } else {
    server = http.createServer(app);
    activeScheme = 'http';
  }

  // -------------------------------------------------------------------------
  // WebSocket server (the real-time game channel)
  // -------------------------------------------------------------------------

  const wss = new WebSocketServer({ server, path: '/ws' });

  wss.on('connection', (ws) => {
    if (players.size >= MAX_PLAYERS) {
      send(ws, 'ERROR', { message: 'This game is full (8 players max).' });
      ws.close();
      return;
    }

    const player = {
      id: crypto.randomUUID(),
      name: null,
      isHost: players.size === 0, // first connection becomes Host
      status: 'typing',
      word: null,
    };
    players.set(ws, player);

    send(ws, 'WELCOME', { id: player.id, isHost: player.isHost, state, round });

    ws.on('message', (raw) => {
      let msg;
      try {
        msg = JSON.parse(raw);
      } catch {
        return;
      }
      handleMessage(ws, player, msg);
    });

    ws.on('close', () => {
      const wasHost = player.isHost;
      players.delete(ws);

      if (players.size === 0) {
        resetToLobby();
        return;
      }

      if (wasHost) promoteNewHost();

      if (state === 'LOBBY') {
        broadcastLobby();
      } else if (state === 'INPUT') {
        broadcastStatus();
        maybeReveal();
      } else {
        // In REVEAL/GAMEOVER, just refresh the roster so the UI stays honest.
        broadcast('PLAYER_LEFT', { players: publicPlayerList() });
      }
    });
  });

  // -------------------------------------------------------------------------
  // Boot
  // -------------------------------------------------------------------------

  server.listen(PORT, () => {
    const addrs = getLanAddresses();
    console.log('');
    console.log(`  ${GAME_NAME} — LAN server running (${activeScheme.toUpperCase()})`);
    console.log('  ------------------------------------');
    console.log(`  On this device, open:  ${activeScheme}://localhost:${PORT}`);
    if (addrs.length) {
      console.log('  Other players on the same Wi-Fi, open:');
      for (const a of addrs) console.log(`    ${activeScheme}://${a}:${PORT}`);
    } else {
      console.log('  Could not detect a LAN IP — make sure this device is on Wi-Fi.');
    }
    console.log('  (A join QR code and a Copy Link button are also on the Host lobby screen.)');
    if (activeScheme === 'https') {
      console.log('');
      console.log('  Note: this uses a private self-signed certificate (no public CA —');
      console.log('  there is no real domain name to certify on a LAN game). Every');
      console.log('  browser will show a "connection is not private" warning on first');
      console.log('  visit — tap Advanced -> Proceed once per device. That is expected.');
      console.log('  To skip HTTPS entirely, restart with MIND_MELD_HTTP=1 set.');
    }
    console.log('');
  });
}

function handleMessage(ws, player, msg) {
  switch (msg.type) {
    case 'JOIN': {
      const name = String(msg.name || '').trim().slice(0, 24) || `Player ${players.size}`;
      player.name = name;
      broadcastLobby();
      break;
    }

    case 'START_GAME': {
      if (!player.isHost) return;
      if (state !== 'LOBBY') return;
      if (players.size < MIN_PLAYERS_TO_START) return;
      startRound();
      break;
    }

    case 'SUBMIT_WORD': {
      if (state !== 'INPUT') return;
      if (player.status === 'ready') return; // locked already
      const word = String(msg.word || '').trim().slice(0, 40);
      if (!word) return;
      player.word = word;
      player.status = 'ready';
      broadcastStatus();
      maybeReveal();
      break;
    }

    case 'NEXT_ROUND': {
      if (!player.isHost) return;
      if (state !== 'REVEAL') return;
      round += 1;
      startRound();
      break;
    }

    case 'PLAY_AGAIN': {
      if (!player.isHost) return;
      if (state !== 'GAMEOVER') return;
      resetToLobby();
      break;
    }

    default:
      break;
  }
}

// ---------------------------------------------------------------------------
// UDP discovery beacon (genuine LAN broadcast, dgram/UDP)
// ---------------------------------------------------------------------------
// Browsers cannot bind UDP sockets, so this beacon is consumed by the
// bundled `discover.js` CLI (or any future native client), not by the web
// client. The web client instead uses the QR code / printed IP below.

const udpSocket = dgram.createSocket({ type: 'udp4', reuseAddr: true });

udpSocket.on('error', (err) => {
  console.warn(`[udp] discovery socket error (non-fatal): ${err.message}`);
});

udpSocket.on('message', (msg, rinfo) => {
  try {
    const parsed = JSON.parse(msg.toString());
    if (parsed.type === 'MIND_MELD_DISCOVER') {
      const reply = Buffer.from(
        JSON.stringify({
          type: 'MIND_MELD_ANNOUNCE',
          name: GAME_NAME,
          port: PORT,
          state,
          players: players.size,
          maxPlayers: MAX_PLAYERS,
        })
      );
      udpSocket.send(reply, rinfo.port, rinfo.address);
    }
  } catch {
    // ignore malformed discovery packets
  }
});

udpSocket.bind(UDP_DISCOVERY_PORT, () => {
  try {
    udpSocket.setBroadcast(true);
  } catch (e) {
    // some platforms restrict broadcast without elevated perms — beacon
    // still answers direct discovery requests above.
  }
});

setInterval(() => {
  const beacon = Buffer.from(
    JSON.stringify({
      type: 'MIND_MELD_ANNOUNCE',
      name: GAME_NAME,
      port: PORT,
      state,
      players: players.size,
      maxPlayers: MAX_PLAYERS,
    })
  );
  udpSocket.send(beacon, UDP_DISCOVERY_PORT, '255.255.255.255', (err) => {
    // Broadcast can fail on networks that block it (common on public
    // Wi-Fi / some routers) — that's fine, QR/IP join still works.
  });
}, 2000).unref();

startServer().catch((err) => {
  console.error('Fatal error starting Mind Meld server:', err);
  process.exit(1);
});
