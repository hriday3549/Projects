'use strict';

/**
 * Optional helper: listens for the Host's UDP broadcast beacon and prints
 * any Mind Meld games found on the LAN. Not needed by browser players
 * (they use the QR code / printed IP) — this is for anyone comfortable
 * running Node, or as a starting point for a future native/mobile client.
 *
 * Usage: npm run discover
 */

const dgram = require('dgram');

const UDP_DISCOVERY_PORT = 41234;
const socket = dgram.createSocket({ type: 'udp4', reuseAddr: true });
const seen = new Map();

socket.on('message', (msg, rinfo) => {
  try {
    const data = JSON.parse(msg.toString());
    if (data.type !== 'MIND_MELD_ANNOUNCE') return;
    const key = `${rinfo.address}:${data.port}`;
    if (!seen.has(key)) {
      console.log(`Found "${data.name}" at http://${rinfo.address}:${data.port}  (${data.players}/${data.maxPlayers} players, state: ${data.state})`);
    }
    seen.set(key, Date.now());
  } catch {
    // ignore malformed packets
  }
});

socket.bind(UDP_DISCOVERY_PORT, () => {
  console.log(`Listening for Mind Meld games on the LAN (UDP :${UDP_DISCOVERY_PORT})... Ctrl+C to stop.`);
  socket.setBroadcast(true);
  // Also actively ask any listening host to announce itself immediately.
  const probe = Buffer.from(JSON.stringify({ type: 'MIND_MELD_DISCOVER' }));
  socket.send(probe, UDP_DISCOVERY_PORT, '255.255.255.255');
});
