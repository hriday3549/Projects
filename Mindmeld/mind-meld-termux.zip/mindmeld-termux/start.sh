#!/data/data/com.termux/files/usr/bin/bash
#
# Mind Meld — Termux launcher
# Run this from inside Termux with:  bash start.sh
# It installs Node.js via Termux's own package manager if it's not
# already present, installs the three small server dependencies, then
# starts the game server — same server.js used on desktop/exe, unchanged.

set -e
cd "$(dirname "$0")"

echo ""
echo "  Mind Meld — Termux launcher"
echo "  ----------------------------"

if ! command -v node >/dev/null 2>&1; then
  echo "  Node.js not found — installing via Termux's package manager..."
  pkg update -y
  pkg install -y nodejs
else
  echo "  Node.js found: $(node -v)"
fi

if [ ! -d node_modules ]; then
  echo "  Installing dependencies (express, ws, qrcode)..."
  npm install --omit=dev
fi

# Keep the CPU from sleeping mid-game if Termux:API's wake-lock is
# available. Optional — the game still runs fine without it, but the
# server can get suspended if the screen locks partway through a round.
if command -v termux-wake-lock >/dev/null 2>&1; then
  termux-wake-lock
  echo "  Wake lock acquired — screen can lock without killing the server."
else
  echo "  Tip: install the Termux:API app + package for a wake lock,"
  echo "  so the server survives the screen locking mid-game."
fi

echo ""
echo "  Starting server — leave this window open while you play."
echo ""

node server.js
