'use strict';

/**
 * MIND MELD — LAN client
 * Talks to the Host over WebSocket at ws(s)://<same-host>/ws
 * Protocol (server -> client): WELCOME, LOBBY_UPDATE, ROUND_START,
 *   STATUS_UPDATE, REVEAL, GAME_OVER, PLAYER_LEFT, ERROR
 * Protocol (client -> server): JOIN, START_GAME, SUBMIT_WORD,
 *   NEXT_ROUND, PLAY_AGAIN
 */

const screens = {};
document.querySelectorAll('.screen').forEach((el) => {
  screens[el.dataset.screen] = el;
});

function showScreen(name) {
  Object.values(screens).forEach((el) => el.classList.remove('active'));
  screens[name].classList.add('active');
}

function toast(message) {
  const el = document.getElementById('toast');
  el.textContent = message;
  el.hidden = false;
  clearTimeout(toast._t);
  toast._t = setTimeout(() => { el.hidden = true; }, 3500);
}

// ------------------------------------------------------------------
// Connection
// ------------------------------------------------------------------

let ws = null;
let me = { id: null, isHost: false };
let lockedIn = false;

function connect() {
  const proto = location.protocol === 'https:' ? 'wss' : 'ws';
  ws = new WebSocket(`${proto}://${location.host}/ws`);

  ws.addEventListener('open', () => {
    document.getElementById('conn-status').textContent = 'Connected. Enter a name to join.';
  });

  ws.addEventListener('close', () => {
    document.getElementById('conn-status').textContent = 'Disconnected from host. Reconnecting…';
    setTimeout(connect, 1500);
  });

  ws.addEventListener('error', () => {
    document.getElementById('conn-status').textContent = 'Connection error — retrying…';
  });

  ws.addEventListener('message', (evt) => {
    let msg;
    try { msg = JSON.parse(evt.data); } catch { return; }
    handleServerMessage(msg);
  });
}

function sendMsg(type, payload = {}) {
  if (ws && ws.readyState === WebSocket.OPEN) {
    ws.send(JSON.stringify({ type, ...payload }));
  }
}

connect();

// ------------------------------------------------------------------
// JOIN screen
// ------------------------------------------------------------------

document.getElementById('join-form').addEventListener('submit', (e) => {
  e.preventDefault();
  const name = document.getElementById('name-input').value.trim();
  if (!name) return;
  document.getElementById('join-btn').disabled = true;
  sendMsg('JOIN', { name });
});

// Compulsory name: the browser's native `required` attribute already
// blocks submission when empty, but give it a clearer message, and
// pre-fill a fun random name on load so most people can just hit Connect.
const ADJECTIVES = ['Swift', 'Curious', 'Quiet', 'Bold', 'Bright', 'Lucky', 'Clever', 'Calm', 'Wild', 'Sunny', 'Cosmic', 'Electric'];
const NOUNS = ['Falcon', 'Comet', 'Nebula', 'Otter', 'Wren', 'Fox', 'Lynx', 'Ember', 'Maple', 'Quartz', 'Sparrow', 'Juniper'];

function generateRandomName() {
  const a = ADJECTIVES[Math.floor(Math.random() * ADJECTIVES.length)];
  const n = NOUNS[Math.floor(Math.random() * NOUNS.length)];
  const num = Math.floor(Math.random() * 90) + 10; // 10-99
  return `${a} ${n} ${num}`;
}

const nameInput = document.getElementById('name-input');
nameInput.value = generateRandomName();
nameInput.addEventListener('invalid', () => {
  nameInput.setCustomValidity('Please enter a name to join.');
});
nameInput.addEventListener('input', () => nameInput.setCustomValidity(''));

// ------------------------------------------------------------------
// Sync ring rendering (signature element, reused across phases)
// ------------------------------------------------------------------

function renderRing(container, players, { showStatus }) {
  container.innerHTML = '';
  const n = players.length || 1;
  const radius = container.parentElement.clientWidth / 2 - 30;
  players.forEach((p, i) => {
    const angle = (i / n) * Math.PI * 2 - Math.PI / 2;
    const x = Math.cos(angle) * radius;
    const y = Math.sin(angle) * radius;
    const node = document.createElement('div');
    node.className = 'node';
    if (p.isHost) node.classList.add('host');
    if (showStatus) node.classList.add(p.status === 'ready' ? 'ready' : 'typing');
    node.style.transform = `translate(${x}px, ${y}px)`;
    node.title = p.name + (p.isHost ? ' (host)' : '');
    const initial = document.createElement('span');
    initial.className = 'initial';
    initial.textContent = (p.name || '?').slice(0, 2).toUpperCase();
    node.appendChild(initial);
    container.appendChild(node);
  });
}

// ------------------------------------------------------------------
// LOBBY screen
// ------------------------------------------------------------------

async function loadHostInfo() {
  try {
    const res = await fetch('/api/host-info');
    const data = await res.json();
    const qrBox = document.getElementById('qr-box');
    qrBox.innerHTML = data.qrDataUrl
      ? `<img src="${data.qrDataUrl}" alt="QR code to join" />`
      : '<div class="qr-loading">QR unavailable — use the IP below</div>';
    document.getElementById('ip-list').textContent = data.addresses.length
      ? data.addresses.map((a) => `${a}:${data.port}`).join('  ·  ')
      : `localhost:${data.port} (share your device's Wi-Fi IP)`;
    currentJoinUrl = data.url;
  } catch {
    document.getElementById('ip-list').textContent = 'Could not load join info.';
    currentJoinUrl = null;
  }
}

let currentJoinUrl = null;

async function copyToClipboard(text) {
  if (navigator.clipboard && window.isSecureContext) {
    try {
      await navigator.clipboard.writeText(text);
      return true;
    } catch {
      // fall through to legacy method
    }
  }
  try {
    const el = document.createElement('textarea');
    el.value = text;
    el.style.position = 'fixed';
    el.style.opacity = '0';
    document.body.appendChild(el);
    el.focus();
    el.select();
    const ok = document.execCommand('copy');
    document.body.removeChild(el);
    return ok;
  } catch {
    return false;
  }
}

document.getElementById('copy-link-btn').addEventListener('click', async () => {
  const btn = document.getElementById('copy-link-btn');
  if (!currentJoinUrl) {
    toast('Join link not ready yet — try again in a moment.');
    return;
  }
  const ok = await copyToClipboard(currentJoinUrl);
  if (ok) {
    btn.textContent = 'Copied!';
    btn.classList.add('copied');
    toast('Join link copied.');
  } else {
    toast(currentJoinUrl); // last resort: show it so they can copy manually
  }
  setTimeout(() => {
    btn.textContent = 'Copy join link';
    btn.classList.remove('copied');
  }, 2000);
});

document.getElementById('start-btn').addEventListener('click', () => sendMsg('START_GAME'));

function renderLobby(data) {
  document.getElementById('host-panel').hidden = !me.isHost;
  document.getElementById('guest-panel').hidden = me.isHost;
  if (me.isHost) {
    const btn = document.getElementById('start-btn');
    btn.disabled = !data.canStart;
    document.getElementById('start-hint').textContent = data.canStart
      ? `${data.players.length} players linked in — ready when you are.`
      : `Need at least ${data.minPlayers} players (${data.players.length} connected).`;
  }
  renderRing(document.getElementById('lobby-ring'), data.players, { showStatus: false });
}

// ------------------------------------------------------------------
// INPUT screen
// ------------------------------------------------------------------

const wordForm = document.getElementById('word-form');
const wordInput = document.getElementById('word-input');

wordForm.addEventListener('submit', (e) => {
  e.preventDefault();
  const word = wordInput.value.trim();
  if (!word || lockedIn) return;
  sendMsg('SUBMIT_WORD', { word });
  lockedIn = true;
  wordInput.disabled = true;
  document.getElementById('lock-btn').disabled = true;
  document.getElementById('locked-msg').hidden = false;
});

function renderRoundStart(data) {
  lockedIn = false;
  wordInput.value = '';
  wordInput.disabled = false;
  wordInput.placeholder = data.round === 1 ? 'Type any word…' : 'Find the middle ground…';
  document.getElementById('lock-btn').disabled = false;
  document.getElementById('locked-msg').hidden = true;
  document.getElementById('round-num').textContent = data.round;

  const promptEl = document.getElementById('input-prompt');
  const poolEl = document.getElementById('prev-pool');
  if (data.round === 1) {
    promptEl.textContent = "Think of any word. Don't overthink it.";
    poolEl.hidden = true;
    poolEl.innerHTML = '';
  } else {
    promptEl.textContent = 'No match yet. Find a word that connects these:';
    poolEl.hidden = false;
    poolEl.innerHTML = (data.previousWords || [])
      .map((w) => `<span class="pool-chip">${escapeHtml(w)}</span>`)
      .join('');
  }

  renderInputRing(data.players);
  showScreen('input');
  setTimeout(() => wordInput.focus(), 200);
}

function renderInputRing(players) {
  renderRing(document.getElementById('input-ring'), players, { showStatus: true });
  const readyCount = players.filter((p) => p.status === 'ready').length;
  document.getElementById('lock-count').textContent = `${readyCount}/${players.length}`;
}

// ------------------------------------------------------------------
// REVEAL screen
// ------------------------------------------------------------------

document.getElementById('next-round-btn').addEventListener('click', () => sendMsg('NEXT_ROUND'));

function renderReveal(data) {
  document.getElementById('reveal-round-num').textContent = data.round;
  document.getElementById('reveal-headline').textContent = data.isMeld
    ? 'Perfect sync!'
    : "Here's what everyone said";

  const grid = document.getElementById('word-grid');
  grid.innerHTML = data.words
    .map(
      (w, i) => `
      <div class="word-card${data.isMeld ? ' match' : ''}" style="animation-delay:${i * 60}ms">
        <p class="who">${escapeHtml(w.name)}</p>
        <p class="what">${escapeHtml(w.word)}</p>
      </div>`
    )
    .join('');

  document.getElementById('next-round-btn').hidden = data.isMeld || !me.isHost;
  document.getElementById('reveal-wait').hidden = data.isMeld || me.isHost;
  showScreen('reveal');
}

// ------------------------------------------------------------------
// GAME OVER screen
// ------------------------------------------------------------------

document.getElementById('again-btn').addEventListener('click', () => sendMsg('PLAY_AGAIN'));

function renderGameOver(data) {
  document.getElementById('victory-word').textContent = data.words[0]?.word || '';
  document.getElementById('victory-meta').textContent =
    `It took ${data.round} round${data.round === 1 ? '' : 's'} and ${data.words.length} players.`;
  document.getElementById('again-btn').hidden = !me.isHost;
  document.getElementById('again-wait').hidden = me.isHost;
  showScreen('gameover');
}

// ------------------------------------------------------------------
// Message dispatch
// ------------------------------------------------------------------

function handleServerMessage(msg) {
  switch (msg.type) {
    case 'WELCOME':
      me.id = msg.id;
      me.isHost = msg.isHost;
      break;

    case 'LOBBY_UPDATE':
      showScreen('lobby');
      const self = msg.players.find((p) => p.id === me.id);
      if (self) me.isHost = self.isHost;
      renderLobby(msg);
      if (me.isHost) loadHostInfo();
      break;

    case 'ROUND_START':
      renderRoundStart(msg);
      break;

    case 'STATUS_UPDATE':
      renderInputRing(msg.players);
      break;

    case 'REVEAL':
      renderReveal(msg);
      break;

    case 'GAME_OVER':
      renderGameOver(msg);
      break;

    case 'PLAYER_LEFT':
      // Roster changed mid REVEAL/GAMEOVER — nothing to re-render urgently.
      break;

    case 'ERROR':
      toast(msg.message || 'Something went wrong.');
      break;

    default:
      break;
  }
}

function escapeHtml(str) {
  const div = document.createElement('div');
  div.textContent = str;
  return div.innerHTML;
}

window.addEventListener('resize', () => {
  // Re-lay the currently visible ring so it stays centered on rotation/resize.
  if (screens.lobby.classList.contains('active')) {
    document.getElementById('lobby-ring').dispatchEvent(new Event('noop'));
  }
});
