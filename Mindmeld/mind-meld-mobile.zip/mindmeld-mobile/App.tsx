import React, { useState } from 'react';
import { SafeAreaView, StyleSheet, StatusBar, Text, View } from 'react-native';
import { StatusBar as ExpoStatusBar } from 'expo-status-bar';
import { colors, fonts } from '@/theme/tokens';
import { useGameSocket } from '@/hooks/useGameSocket';
import { ConnectScreen } from '@/screens/ConnectScreen';
import { LobbyScreen } from '@/screens/LobbyScreen';
import { InputScreen } from '@/screens/InputScreen';
import { RevealScreen } from '@/screens/RevealScreen';
import { GameOverScreen } from '@/screens/GameOverScreen';
import type { HostAddress } from '@/types';

export default function App() {
  const [address, setAddress] = useState<HostAddress | null>(null);
  const [pendingName, setPendingName] = useState<string>('');

  const socket = useGameSocket(address);

  const handleConnect = (nextAddress: HostAddress, name: string) => {
    setPendingName(name);
    setAddress(nextAddress);
  };

  // Once the socket opens, send JOIN with the name captured on the Connect screen.
  React.useEffect(() => {
    if (socket.connectionStatus === 'open' && pendingName) {
      socket.join(pendingName);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [socket.connectionStatus]);

  return (
    <SafeAreaView style={styles.safe}>
      <ExpoStatusBar style="light" />
      <StatusBar barStyle="light-content" />

      {socket.phase === 'connect' && (
        <ConnectScreen connectionStatus={socket.connectionStatus} onConnect={handleConnect} />
      )}

      {socket.phase === 'lobby' && socket.lobby && (
        <LobbyScreen lobby={socket.lobby} isHost={socket.me.isHost} onStart={socket.startGame} />
      )}

      {socket.phase === 'input' && socket.round && (
        <InputScreen
          round={socket.round}
          liveStatusPlayers={socket.liveStatusPlayers}
          onSubmit={socket.submitWord}
        />
      )}

      {socket.phase === 'reveal' && socket.reveal && (
        <RevealScreen reveal={socket.reveal} isHost={socket.me.isHost} onNextRound={socket.nextRound} />
      )}

      {socket.phase === 'gameover' && socket.gameOver && (
        <GameOverScreen gameOver={socket.gameOver} isHost={socket.me.isHost} onPlayAgain={socket.playAgain} />
      )}

      {socket.errorMessage && (
        <View style={styles.toast}>
          <Text style={styles.toastText}>{socket.errorMessage}</Text>
        </View>
      )}
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safe: { flex: 1, backgroundColor: colors.bg },
  toast: {
    position: 'absolute',
    bottom: 30,
    alignSelf: 'center',
    backgroundColor: colors.danger,
    borderRadius: 100,
    paddingHorizontal: 18,
    paddingVertical: 10,
  },
  toastText: { fontFamily: fonts.mono, fontSize: 13, color: '#1A0A0D' },
});
