# Mind Meld — Mobile (Expo / React Native)

The native player app for **Mind Meld LAN**. It's the same game as the
web version — the Host still runs `server.js` on a laptop/desktop, same
as before, with **zero changes** — this app just replaces "open a
browser and type an IP" with **point your camera at the Host's QR code**.

It talks the exact same WebSocket protocol as `public/client.js` in the
main project, so it works with the existing server unmodified.

## Run it

You need the LAN server (`mind-meld-lan/`) already running somewhere on
your Wi-Fi — see its own README. Then, on your dev machine:

```bash
npm install
npx expo start
```

Scan the Metro QR code with the **Expo Go** app (iOS/Android) to load
Mind Meld onto your phone during development. That QR is just for
loading the app itself — it's separate from the in-game "scan to join"
QR shown on the Host's Lobby screen once you're playing.

For a real installable build (not just Expo Go), use
[EAS Build](https://docs.expo.dev/build/introduction/):

```bash
npx eas build --platform android   # or ios
```

## How joining works

1. Open the app, type your name — a fun random one is pre-filled, so
   most people can just tap Connect.
2. Tap **Scan host's QR code** and point the camera at the Host's
   Lobby screen (the same QR the web client already generates via
   `/api/host-info`). The app parses the join URL and connects.
3. Can't scan (no line of sight, camera issue)? Tap **"Can't scan?
   Enter the host's IP instead"** and type `192.168.1.42:3000` — the
   IP printed in the Host's terminal, or "IP" text on their Lobby screen.

From there it's the same game: Lobby → round input → reveal → meld or
next round, with haptic feedback on lock-in and on a winning meld.

## Important: HTTPS hosts and this app

The main server now defaults to **HTTPS** (a private, self-signed
certificate — see the main project's README). Browsers handle that
with a one-time "this connection isn't private, proceed anyway" click.
This app doesn't have an equivalent yet: React Native's built-in
`WebSocket` has no supported way to accept a self-signed certificate
from plain JS, so scanning a `https://` QR will produce a `wss://`
connection that **fails**.

Until this app ships with a proper trust configuration (a custom dev
client with an Android network security config + iOS ATS exception
pinned to the game's cert — real work, not done here), the practical
fix is running the Host with `MIND_MELD_HTTP=1` set when you're
playing with this app. That makes the Host's QR encode a plain
`http://` URL, which this app connects to normally over `ws://`. The
Connect screen's error message says as much if a connection fails.

## Architecture

- **Still a listen-server model.** This app is a *client only* — it
  never opens a socket for others to connect to. Whoever's laptop is
  running `server.js` is the network Host. The **in-game host** role
  (who can click Start / Next round / Play again) is just whichever
  player connected first, and can be this phone.
- **`src/hooks/useGameSocket.ts`** owns the WebSocket connection and
  mirrors the exact message set the server already speaks —
  `JOIN` / `START_GAME` / `SUBMIT_WORD` / `NEXT_ROUND` / `PLAY_AGAIN`
  out, `WELCOME` / `LOBBY_UPDATE` / `ROUND_START` / `STATUS_UPDATE` /
  `REVEAL` / `GAME_OVER` in. It auto-reconnects if Wi-Fi hiccups.
- **`src/screens/ScannerScreen.tsx`** uses `expo-camera`'s built-in QR
  scanning to read the Host's join URL — this is the app's main reason
  to exist over just using the browser.
- **`src/components/SyncRing.tsx`** ports the web client's signature
  "sync ring" visual (player nodes arranged in a circle, glowing violet
  while typing and amber once locked in) to React Native with the same
  trig-based layout.

## Files

```
App.tsx                      Phase router — wires useGameSocket to screens
app.json                     Expo config (camera permission strings)
src/types.ts                 Shared protocol types
src/hooks/useGameSocket.ts   WebSocket client + protocol handling
src/hooks/parseHostAddress.ts  QR/manual-entry -> {host, port}
src/screens/*                Connect, Scanner, Lobby, Input, Reveal, GameOver
src/components/*             SyncRing, PrimaryButton, PhaseHeader
src/theme/tokens.ts           Colors/fonts ported from the web client's CSS
```

## Testing notes

There's no Android/iOS simulator available in the environment this was
built in, so it hasn't been run on-device. What *was* verified:

- Every `.ts`/`.tsx` file parses cleanly (Babel, TS+JSX presets) — no
  syntax errors.
- `parseHostAddress` was unit-tested against 6 real inputs (full QR
  URL, `ip:port` shorthand, bare IP, garbage input, empty string, and a
  `.local` hostname with a non-default port) — all passed.
- The protocol logic in `useGameSocket.ts` is a direct port of
  `public/client.js`'s `handleServerMessage`, which *was* exercised
  end-to-end against the real server in a 3-client simulation (see the
  main project's delivery notes).

Before your first real playtest: confirm `expo-camera`'s QR scanning
works on your target device/OS version (Expo SDK versions occasionally
shift that API), and double check the Host's phone/laptop firewall
allows inbound connections on the server's port.
