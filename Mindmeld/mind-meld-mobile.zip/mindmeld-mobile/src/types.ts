export type GamePhase = 'connect' | 'lobby' | 'input' | 'reveal' | 'gameover';

export interface Player {
  id: string;
  name: string;
  isHost: boolean;
  status?: 'typing' | 'ready';
}

export interface RevealWord {
  id: string;
  name: string;
  word: string;
}

export interface LobbyState {
  players: Player[];
  canStart: boolean;
  minPlayers: number;
  maxPlayers: number;
}

export interface RoundState {
  round: number;
  players: Player[];
  previousWords: string[];
}

export interface RevealState {
  round: number;
  words: RevealWord[];
  isMeld: boolean;
}

export interface GameOverState {
  round: number;
  words: RevealWord[];
}

/** Parsed from the Host's join QR (which encodes e.g. https://192.168.1.42:3000/) */
export interface HostAddress {
  host: string;
  port: number;
  /** 'wss' when the scanned/typed URL was https — see parseHostAddress.ts
   * for the important caveat about self-signed certs and this app. */
  scheme: 'ws' | 'wss';
}
