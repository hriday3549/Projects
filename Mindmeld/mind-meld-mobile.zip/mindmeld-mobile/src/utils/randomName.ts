const ADJECTIVES = [
  'Swift', 'Curious', 'Quiet', 'Bold', 'Bright', 'Lucky',
  'Clever', 'Calm', 'Wild', 'Sunny', 'Cosmic', 'Electric',
];
const NOUNS = [
  'Falcon', 'Comet', 'Nebula', 'Otter', 'Wren', 'Fox',
  'Lynx', 'Ember', 'Maple', 'Quartz', 'Sparrow', 'Juniper',
];

/** Same word lists and format as the web client, so a "Swift Falcon 42"
 * style name feels consistent whichever device someone's joining from. */
export function generateRandomName(): string {
  const a = ADJECTIVES[Math.floor(Math.random() * ADJECTIVES.length)];
  const n = NOUNS[Math.floor(Math.random() * NOUNS.length)];
  const num = Math.floor(Math.random() * 90) + 10; // 10-99
  return `${a} ${n} ${num}`;
}
