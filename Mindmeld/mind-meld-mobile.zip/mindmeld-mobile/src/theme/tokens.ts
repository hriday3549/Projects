import { Platform } from 'react-native';

/**
 * Same token system as the web client (public/style.css), ported to
 * React Native. No custom font files are bundled — the "display" look
 * comes from weight/letter-spacing on the system font, which keeps the
 * app installable without extra asset downloads.
 */
export const colors = {
  bg: '#100E1B',
  surface: '#1B1830',
  surface2: '#241F3D',
  line: '#322B52',
  text: '#F1EEFB',
  dim: '#9791B3',
  violet: '#8C6BFF',
  violetDim: '#4A3F85',
  amber: '#FFB454',
  meld: '#6BFFB8',
  danger: '#FF6B81',
};

export const fonts = {
  display: Platform.select({ ios: 'Avenir Next', android: 'sans-serif-medium', default: 'System' }),
  body: Platform.select({ ios: 'System', android: 'sans-serif', default: 'System' }),
  mono: Platform.select({ ios: 'Menlo', android: 'monospace', default: 'monospace' }),
};

export const spacing = (n: number) => n * 4;

export const radii = {
  sm: 10,
  md: 14,
  lg: 16,
  pill: 100,
};
