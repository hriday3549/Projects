import React, { useState } from 'react';
import { View, Text, StyleSheet, LayoutChangeEvent } from 'react-native';
import { colors, fonts } from '@/theme/tokens';
import type { Player } from '@/types';

interface SyncRingProps {
  players: Player[];
  showStatus: boolean;
  centerLabel?: string;
}

const NODE_SIZE = 46;

export function SyncRing({ players, showStatus, centerLabel }: SyncRingProps) {
  const [size, setSize] = useState(0);

  const onLayout = (e: LayoutChangeEvent) => {
    setSize(e.nativeEvent.layout.width);
  };

  const radius = size ? size / 2 - NODE_SIZE / 2 - 6 : 0;
  const center = size / 2;
  const n = players.length || 1;

  return (
    <View style={styles.wrap} onLayout={onLayout}>
      <View style={styles.ringOutline} />
      <View style={styles.ringInner} />
      {centerLabel ? <Text style={styles.centerLabel}>{centerLabel}</Text> : null}
      {size > 0 &&
        players.map((p, i) => {
          const angle = (i / n) * Math.PI * 2 - Math.PI / 2;
          const x = center + Math.cos(angle) * radius - NODE_SIZE / 2;
          const y = center + Math.sin(angle) * radius - NODE_SIZE / 2;
          const status = showStatus ? p.status : undefined;
          return (
            <View
              key={p.id}
              style={[
                styles.node,
                { left: x, top: y },
                status === 'ready' && styles.nodeReady,
                status === 'typing' && styles.nodeTyping,
              ]}
            >
              {p.isHost ? <View style={styles.hostDot} /> : null}
              <Text
                style={[
                  styles.initials,
                  status === 'ready' && { color: colors.amber },
                  status === 'typing' && { color: colors.violet },
                ]}
              >
                {(p.name || '?').slice(0, 2).toUpperCase()}
              </Text>
            </View>
          );
        })}
    </View>
  );
}

const styles = StyleSheet.create({
  wrap: {
    width: '100%',
    aspectRatio: 1,
    maxWidth: 300,
    alignSelf: 'center',
    alignItems: 'center',
    justifyContent: 'center',
    marginVertical: 12,
  },
  ringOutline: {
    position: 'absolute',
    width: '100%',
    height: '100%',
    borderRadius: 999,
    borderWidth: 1,
    borderColor: colors.line,
    borderStyle: 'dashed',
  },
  ringInner: {
    position: 'absolute',
    width: '64%',
    height: '64%',
    borderRadius: 999,
    borderWidth: 1,
    borderColor: 'rgba(140,107,255,0.15)',
  },
  centerLabel: {
    fontFamily: fonts.mono,
    fontSize: 22,
    color: colors.text,
  },
  node: {
    position: 'absolute',
    width: NODE_SIZE,
    height: NODE_SIZE,
    borderRadius: NODE_SIZE / 2,
    backgroundColor: colors.surface,
    borderWidth: 2,
    borderColor: colors.violetDim,
    alignItems: 'center',
    justifyContent: 'center',
  },
  nodeTyping: {
    borderColor: colors.violet,
  },
  nodeReady: {
    borderColor: colors.amber,
    backgroundColor: 'rgba(255,180,84,0.12)',
  },
  hostDot: {
    position: 'absolute',
    top: -2,
    right: -2,
    width: 8,
    height: 8,
    borderRadius: 4,
    backgroundColor: colors.meld,
  },
  initials: {
    fontFamily: fonts.mono,
    fontSize: 11,
    color: colors.dim,
  },
});
