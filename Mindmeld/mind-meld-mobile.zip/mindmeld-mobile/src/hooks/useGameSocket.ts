import { useCallback, useEffect, useRef, useState } from 'react';
import type {
  GamePhase,
  GameOverState,
  HostAddress,
  LobbyState,
  Player,
  RevealState,
  RoundState,
} from '@/types';

interface Me {
  id: string | null;
  isHost: boolean;
}

interface UseGameSocketResult {
  connectionStatus: 'idle' | 'connecting' | 'open' | 'closed' | 'error';
  phase: GamePhase;
  me: Me;
  lobby: LobbyState | null;
  round: RoundState | null;
  liveStatusPlayers: Player[] | null; // updated by STATUS_UPDATE between rounds
  reveal: RevealState | null;
  gameOver: GameOverState | null;
  errorMessage: string | null;
  join: (name: string) => void;
  startGame: () => void;
  submitWord: (word: string) => void;
  nextRound: () => void;
  playAgain: () => void;
  disconnect: () => void;
}

/**
 * Same wire protocol as public/client.js on the LAN server:
 *   client -> server: JOIN, START_GAME, SUBMIT_WORD, NEXT_ROUND, PLAY_AGAIN
 *   server -> client: WELCOME, LOBBY_UPDATE, ROUND_START, STATUS_UPDATE,
 *                      REVEAL, GAME_OVER, PLAYER_LEFT, ERROR
 * No server-side changes were needed to support this native client.
 */
export function useGameSocket(address: HostAddress | null): UseGameSocketResult {
  const wsRef = useRef<WebSocket | null>(null);
  const reconnectTimer = useRef<ReturnType<typeof setTimeout> | null>(null);
  const pendingName = useRef<string | null>(null);
  const manuallyClosed = useRef(false);

  const [connectionStatus, setConnectionStatus] = useState<UseGameSocketResult['connectionStatus']>('idle');
  const [phase, setPhase] = useState<GamePhase>('connect');
  const [me, setMe] = useState<Me>({ id: null, isHost: false });
  const [lobby, setLobby] = useState<LobbyState | null>(null);
  const [round, setRound] = useState<RoundState | null>(null);
  const [liveStatusPlayers, setLiveStatusPlayers] = useState<Player[] | null>(null);
  const [reveal, setReveal] = useState<RevealState | null>(null);
  const [gameOver, setGameOver] = useState<GameOverState | null>(null);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);

  const send = useCallback((type: string, payload: Record<string, unknown> = {}) => {
    const ws = wsRef.current;
    if (ws && ws.readyState === WebSocket.OPEN) {
      ws.send(JSON.stringify({ type, ...payload }));
    }
  }, []);

  const connect = useCallback(() => {
    if (!address) return;
    manuallyClosed.current = false;
    setConnectionStatus('connecting');

    const ws = new WebSocket(`${address.scheme}://${address.host}:${address.port}/ws`);
    wsRef.current = ws;

    ws.onopen = () => {
      setConnectionStatus('open');
      if (pendingName.current) {
        send('JOIN', { name: pendingName.current });
      }
    };

    ws.onclose = () => {
      setConnectionStatus('closed');
      if (!manuallyClosed.current) {
        reconnectTimer.current = setTimeout(connect, 1500);
      }
    };

    ws.onerror = () => {
      setConnectionStatus('error');
    };

    ws.onmessage = (evt) => {
      let msg: any;
      try {
        msg = JSON.parse(evt.data);
      } catch {
        return;
      }
      handleMessage(msg);
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [address, send]);

  const handleMessage = useCallback((msg: any) => {
    switch (msg.type) {
      case 'WELCOME':
        setMe({ id: msg.id, isHost: msg.isHost });
        break;

      case 'LOBBY_UPDATE': {
        setLobby({
          players: msg.players,
          canStart: msg.canStart,
          minPlayers: msg.minPlayers,
          maxPlayers: msg.maxPlayers,
        });
        setMe((prev) => {
          const self = (msg.players as Player[]).find((p) => p.id === prev.id);
          return self ? { ...prev, isHost: self.isHost } : prev;
        });
        setPhase('lobby');
        break;
      }

      case 'ROUND_START':
        setRound({ round: msg.round, players: msg.players, previousWords: msg.previousWords || [] });
        setLiveStatusPlayers(msg.players);
        setPhase('input');
        break;

      case 'STATUS_UPDATE':
        setLiveStatusPlayers(msg.players);
        break;

      case 'REVEAL':
        setReveal({ round: msg.round, words: msg.words, isMeld: msg.isMeld });
        setPhase('reveal');
        break;

      case 'GAME_OVER':
        setGameOver({ round: msg.round, words: msg.words });
        setPhase('gameover');
        break;

      case 'PLAYER_LEFT':
        // Roster changed mid REVEAL/GAMEOVER — no phase change needed.
        break;

      case 'ERROR':
        setErrorMessage(msg.message || 'Something went wrong.');
        break;

      default:
        break;
    }
  }, []);

  useEffect(() => {
    if (address) connect();
    return () => {
      manuallyClosed.current = true;
      if (reconnectTimer.current) clearTimeout(reconnectTimer.current);
      wsRef.current?.close();
      wsRef.current = null;
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [address]);

  const join = useCallback(
    (name: string) => {
      pendingName.current = name;
      if (wsRef.current && wsRef.current.readyState === WebSocket.OPEN) {
        send('JOIN', { name });
      }
    },
    [send]
  );

  const startGame = useCallback(() => send('START_GAME'), [send]);
  const submitWord = useCallback((word: string) => send('SUBMIT_WORD', { word }), [send]);
  const nextRound = useCallback(() => send('NEXT_ROUND'), [send]);
  const playAgain = useCallback(() => send('PLAY_AGAIN'), [send]);

  const disconnect = useCallback(() => {
    manuallyClosed.current = true;
    if (reconnectTimer.current) clearTimeout(reconnectTimer.current);
    wsRef.current?.close();
    wsRef.current = null;
    setConnectionStatus('idle');
    setPhase('connect');
    setLobby(null);
    setRound(null);
    setReveal(null);
    setGameOver(null);
    setMe({ id: null, isHost: false });
  }, []);

  return {
    connectionStatus,
    phase,
    me,
    lobby,
    round,
    liveStatusPlayers,
    reveal,
    gameOver,
    errorMessage,
    join,
    startGame,
    submitWord,
    nextRound,
    playAgain,
    disconnect,
  };
}
