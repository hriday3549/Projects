import type { HostAddress } from '@/types';

/**
 * The Host's Lobby QR encodes a plain join URL like:
 *   https://192.168.1.42:3000/   (the server defaults to HTTPS now)
 * This also accepts manual entry shorthand like "192.168.1.42:3000"
 * or just "192.168.1.42" (defaults to port 3000, the server's default,
 * and to plain ws:// — see the caveat below on why).
 *
 * IMPORTANT CAVEAT: the Host server's HTTPS mode uses a private
 * self-signed certificate (there's no real CA for a LAN game). Browsers
 * handle that with a one-time "proceed anyway" click. This app's
 * WebSocket connection has no equivalent — React Native's built-in
 * WebSocket has no supported way to accept a self-signed cert from
 * plain JS, so a scanned https:// QR will produce a wss:// URL here
 * that will fail to connect. Until this app ships with a custom trust
 * config, the practical fix is running the Host with `MIND_MELD_HTTP=1`
 * (see the main project's README) when playing with this app, which
 * makes the QR encode a plain http:// URL and this connects normally.
 */
export function parseHostAddress(raw: string): HostAddress | null {
  const input = raw.trim();
  if (!input) return null;

  try {
    const withScheme = /^https?:\/\//i.test(input) ? input : `http://${input}`;
    const url = new URL(withScheme);
    const host = url.hostname;
    const port = url.port ? Number(url.port) : 3000;
    if (!host || Number.isNaN(port)) return null;
    const scheme: HostAddress['scheme'] = url.protocol === 'https:' ? 'wss' : 'ws';
    return { host, port, scheme };
  } catch {
    return null;
  }
}
