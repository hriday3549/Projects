import React from 'react';
import { View, Text, StyleSheet } from 'react-native';
import { colors, fonts, radii } from '@/theme/tokens';
import { PhaseHeader } from '@/components/PhaseHeader';
import { PrimaryButton } from '@/components/PrimaryButton';
import type { RevealState } from '@/types';

interface RevealScreenProps {
  reveal: RevealState;
  isHost: boolean;
  onNextRound: () => void;
}

export function RevealScreen({ reveal, isHost, onNextRound }: RevealScreenProps) {
  return (
    <View style={styles.wrap}>
      <PhaseHeader
        eyebrow={`round ${reveal.round} · reveal`}
        title={reveal.isMeld ? 'Perfect sync!' : "Here's what everyone said"}
      />

      <View style={styles.grid}>
        {reveal.words.map((w) => (
          <View key={w.id} style={[styles.card, reveal.isMeld && styles.cardMatch]}>
            <Text style={styles.who}>{w.name}</Text>
            <Text style={[styles.what, reveal.isMeld && { color: colors.meld }]}>{w.word}</Text>
          </View>
        ))}
      </View>

      {!reveal.isMeld && (
        <View style={styles.actions}>
          {isHost ? (
            <PrimaryButton label="Next round" onPress={onNextRound} style={{ width: '100%' }} />
          ) : (
            <Text style={styles.hint}>Waiting for the host to continue…</Text>
          )}
        </View>
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  wrap: { flex: 1, backgroundColor: colors.bg, paddingHorizontal: 24, paddingTop: 70, alignItems: 'center' },
  grid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    justifyContent: 'center',
    gap: 12,
    marginTop: 8,
    marginBottom: 24,
    width: '100%',
  },
  card: {
    minWidth: 130,
    flexGrow: 1,
    backgroundColor: colors.surface,
    borderWidth: 1,
    borderColor: colors.line,
    borderRadius: radii.md,
    paddingVertical: 16,
    paddingHorizontal: 12,
  },
  cardMatch: {
    borderColor: colors.meld,
  },
  who: { fontFamily: fonts.mono, fontSize: 11, color: colors.dim, marginBottom: 6 },
  what: { fontFamily: fonts.display, fontWeight: '700', fontSize: 18, color: colors.text },
  actions: { width: '100%', maxWidth: 320 },
  hint: { fontFamily: fonts.body, fontSize: 13, color: colors.dim, textAlign: 'center' },
});
