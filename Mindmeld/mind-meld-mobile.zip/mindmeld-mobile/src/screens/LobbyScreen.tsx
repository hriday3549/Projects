import React from 'react';
import { View, Text, StyleSheet } from 'react-native';
import { colors, fonts } from '@/theme/tokens';
import { PhaseHeader } from '@/components/PhaseHeader';
import { PrimaryButton } from '@/components/PrimaryButton';
import { SyncRing } from '@/components/SyncRing';
import type { LobbyState } from '@/types';

interface LobbyScreenProps {
  lobby: LobbyState;
  isHost: boolean;
  onStart: () => void;
}

export function LobbyScreen({ lobby, isHost, onStart }: LobbyScreenProps) {
  return (
    <View style={styles.wrap}>
      <PhaseHeader eyebrow="lobby" title="Waiting for minds to link up" />
      <SyncRing players={lobby.players} showStatus={false} />

      <View style={styles.panel}>
        {isHost ? (
          <>
            <Text style={styles.panelLabel}>You're hosting this round</Text>
            <Text style={styles.hint}>
              {lobby.canStart
                ? `${lobby.players.length} players linked in — ready when you are.`
                : `Need at least ${lobby.minPlayers} players (${lobby.players.length} connected). Everyone else scans the QR code on the host computer's screen to join.`}
            </Text>
            <PrimaryButton
              label="Start game"
              onPress={onStart}
              disabled={!lobby.canStart}
              style={{ marginTop: 16, width: '100%' }}
            />
          </>
        ) : (
          <>
            <Text style={styles.panelLabel}>You're in</Text>
            <Text style={styles.hint}>Waiting for the host to start the round…</Text>
          </>
        )}
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  wrap: { flex: 1, backgroundColor: colors.bg, paddingHorizontal: 24, paddingTop: 70, alignItems: 'center' },
  panel: {
    width: '100%',
    maxWidth: 340,
    backgroundColor: colors.surface,
    borderWidth: 1,
    borderColor: colors.line,
    borderRadius: 16,
    padding: 22,
    marginTop: 12,
  },
  panelLabel: {
    fontFamily: fonts.mono,
    fontSize: 11,
    letterSpacing: 1.4,
    textTransform: 'uppercase',
    color: colors.dim,
    marginBottom: 10,
  },
  hint: { fontFamily: fonts.body, fontSize: 14, color: colors.dim, lineHeight: 20 },
});
