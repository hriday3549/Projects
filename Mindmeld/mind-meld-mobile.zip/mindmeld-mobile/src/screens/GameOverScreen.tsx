import React, { useEffect } from 'react';
import { View, Text, StyleSheet } from 'react-native';
import * as Haptics from 'expo-haptics';
import { colors, fonts, radii } from '@/theme/tokens';
import { PrimaryButton } from '@/components/PrimaryButton';
import type { GameOverState } from '@/types';

interface GameOverScreenProps {
  gameOver: GameOverState;
  isHost: boolean;
  onPlayAgain: () => void;
}

export function GameOverScreen({ gameOver, isHost, onPlayAgain }: GameOverScreenProps) {
  useEffect(() => {
    Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success).catch(() => {});
  }, []);

  const word = gameOver.words[0]?.word ?? '';

  return (
    <View style={styles.wrap}>
      <Text style={styles.eyebrow}>group mind meld</Text>
      <Text style={styles.title}>MELDED</Text>
      <Text style={styles.sub}>Every mind landed on the same word.</Text>

      <View style={styles.wordPill}>
        <Text style={styles.wordText}>{word}</Text>
      </View>

      <Text style={styles.meta}>
        It took {gameOver.round} round{gameOver.round === 1 ? '' : 's'} and {gameOver.words.length} players.
      </Text>

      {isHost ? (
        <PrimaryButton label="Play again" onPress={onPlayAgain} style={{ width: '100%', maxWidth: 300 }} />
      ) : (
        <Text style={styles.hint}>Waiting for the host to restart…</Text>
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  wrap: { flex: 1, backgroundColor: colors.bg, paddingHorizontal: 24, paddingTop: 110, alignItems: 'center' },
  eyebrow: {
    fontFamily: fonts.mono,
    fontSize: 12,
    letterSpacing: 2,
    textTransform: 'uppercase',
    color: colors.violet,
    marginBottom: 6,
  },
  title: {
    fontFamily: fonts.display,
    fontWeight: '800',
    fontSize: 56,
    color: colors.meld,
    letterSpacing: -0.5,
    marginBottom: 6,
  },
  sub: { fontFamily: fonts.body, fontSize: 14, color: colors.dim, marginBottom: 22 },
  wordPill: {
    borderWidth: 1,
    borderColor: 'rgba(107,255,184,0.4)',
    backgroundColor: colors.surface,
    borderRadius: radii.pill,
    paddingHorizontal: 22,
    paddingVertical: 10,
    marginBottom: 10,
  },
  wordText: { fontFamily: fonts.mono, fontSize: 18, color: colors.text },
  meta: { fontFamily: fonts.body, fontSize: 13, color: colors.dim, marginBottom: 28 },
  hint: { fontFamily: fonts.body, fontSize: 13, color: colors.dim, textAlign: 'center' },
});
