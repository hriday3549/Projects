import React, { useState } from 'react';
import { View, Text, TextInput, StyleSheet, KeyboardAvoidingView, Platform } from 'react-native';
import { colors, fonts, radii } from '@/theme/tokens';
import { PrimaryButton } from '@/components/PrimaryButton';
import { ScannerScreen } from '@/screens/ScannerScreen';
import { parseHostAddress } from '@/hooks/parseHostAddress';
import { generateRandomName } from '@/utils/randomName';
import type { HostAddress } from '@/types';

interface ConnectScreenProps {
  connectionStatus: 'idle' | 'connecting' | 'open' | 'closed' | 'error';
  onConnect: (address: HostAddress, name: string) => void;
}

export function ConnectScreen({ connectionStatus, onConnect }: ConnectScreenProps) {
  // Compulsory but pre-filled: a fun random name means most people can
  // just tap Connect, but the field can't be submitted empty (buttons
  // below are disabled while trimmedName is blank).
  const [name, setName] = useState(() => generateRandomName());
  const [manualAddress, setManualAddress] = useState('');
  const [showScanner, setShowScanner] = useState(false);
  const [showManual, setShowManual] = useState(false);

  const trimmedName = name.trim();

  if (showScanner) {
    return (
      <ScannerScreen
        onFound={(address) => {
          setShowScanner(false);
          onConnect(address, trimmedName);
        }}
        onCancel={() => {
          setShowScanner(false);
          setShowManual(true);
        }}
      />
    );
  }

  const handleManualConnect = () => {
    const address = parseHostAddress(manualAddress);
    if (!address) return;
    onConnect(address, trimmedName);
  };

  return (
    <KeyboardAvoidingView
      style={styles.wrap}
      behavior={Platform.OS === 'ios' ? 'padding' : undefined}
    >
      <Text style={styles.eyebrow}>local wi-fi · no internet required</Text>
      <Text style={styles.wordmark}>
        MIND<Text style={{ color: colors.violet }}>MELD</Text>
      </Text>
      <Text style={styles.tagline}>
        Everyone thinks of a word. Nobody discusses. Sync your minds one round at a time.
      </Text>

      <View style={styles.form}>
        <Text style={styles.label}>Your name</Text>
        <TextInput
          value={name}
          onChangeText={setName}
          placeholder="e.g. Riya"
          placeholderTextColor={colors.dim}
          maxLength={24}
          autoCapitalize="words"
          autoCorrect={false}
          style={styles.input}
        />

        {showManual ? (
          <>
            <Text style={styles.label}>Host address</Text>
            <TextInput
              value={manualAddress}
              onChangeText={setManualAddress}
              placeholder="192.168.1.42:3000"
              placeholderTextColor={colors.dim}
              autoCapitalize="none"
              autoCorrect={false}
              keyboardType="url"
              style={styles.input}
            />
            <PrimaryButton
              label={connectionStatus === 'connecting' ? 'Connecting…' : 'Connect'}
              onPress={handleManualConnect}
              disabled={!trimmedName || !manualAddress.trim()}
              loading={connectionStatus === 'connecting'}
              style={{ marginTop: 6 }}
            />
          </>
        ) : (
          <PrimaryButton
            label="Scan host's QR code"
            onPress={() => setShowScanner(true)}
            disabled={!trimmedName}
            style={{ marginTop: 6 }}
          />
        )}

        <Text onPress={() => setShowManual((s) => !s)} style={styles.switchLink}>
          {showManual ? 'Scan a QR code instead' : "Can't scan? Enter the host's IP instead"}
        </Text>

        {connectionStatus === 'error' && (
          <Text style={styles.errorText}>
            Couldn't reach that host. If the host is running in HTTPS mode (the default), this
            app can't yet accept its self-signed certificate — ask the host to restart with
            MIND_MELD_HTTP=1 set, or double-check the IP and Wi-Fi network.
          </Text>
        )}
      </View>
    </KeyboardAvoidingView>
  );
}

const styles = StyleSheet.create({
  wrap: { flex: 1, backgroundColor: colors.bg, paddingHorizontal: 24, paddingTop: 90, alignItems: 'center' },
  eyebrow: {
    fontFamily: fonts.mono,
    fontSize: 12,
    letterSpacing: 2,
    textTransform: 'uppercase',
    color: colors.violet,
    marginBottom: 12,
  },
  wordmark: {
    fontFamily: fonts.display,
    fontWeight: '800',
    fontSize: 46,
    color: colors.text,
    letterSpacing: -0.5,
    marginBottom: 14,
  },
  tagline: {
    fontFamily: fonts.body,
    fontSize: 15,
    color: colors.dim,
    textAlign: 'center',
    lineHeight: 21,
    marginBottom: 36,
    maxWidth: 320,
  },
  form: { width: '100%', maxWidth: 360 },
  label: { fontFamily: fonts.mono, fontSize: 12, color: colors.dim, marginBottom: 6 },
  input: {
    backgroundColor: colors.surface,
    borderWidth: 1,
    borderColor: colors.line,
    borderRadius: radii.sm,
    color: colors.text,
    fontFamily: fonts.body,
    fontSize: 16,
    paddingHorizontal: 16,
    paddingVertical: 14,
    marginBottom: 16,
  },
  switchLink: {
    fontFamily: fonts.body,
    fontSize: 13,
    color: colors.violet,
    textAlign: 'center',
    marginTop: 18,
    textDecorationLine: 'underline',
  },
  errorText: {
    fontFamily: fonts.mono,
    fontSize: 12,
    color: colors.danger,
    textAlign: 'center',
    marginTop: 16,
  },
});
