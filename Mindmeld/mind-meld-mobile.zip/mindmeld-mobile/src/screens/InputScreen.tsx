import React, { useEffect, useState } from 'react';
import { View, Text, TextInput, StyleSheet, KeyboardAvoidingView, Platform } from 'react-native';
import * as Haptics from 'expo-haptics';
import { colors, fonts, radii } from '@/theme/tokens';
import { PhaseHeader } from '@/components/PhaseHeader';
import { PrimaryButton } from '@/components/PrimaryButton';
import { SyncRing } from '@/components/SyncRing';
import type { Player, RoundState } from '@/types';

interface InputScreenProps {
  round: RoundState;
  liveStatusPlayers: Player[] | null;
  onSubmit: (word: string) => void;
}

export function InputScreen({ round, liveStatusPlayers, onSubmit }: InputScreenProps) {
  const [word, setWord] = useState('');
  const [lockedIn, setLockedIn] = useState(false);

  // A fresh ROUND_START means a new round: reset local input state.
  useEffect(() => {
    setWord('');
    setLockedIn(false);
  }, [round.round]);

  const players = liveStatusPlayers ?? round.players;
  const readyCount = players.filter((p) => p.status === 'ready').length;

  const handleSubmit = () => {
    const trimmed = word.trim();
    if (!trimmed || lockedIn) return;
    onSubmit(trimmed);
    setLockedIn(true);
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium).catch(() => {});
  };

  const isFirstRound = round.round === 1;

  return (
    <KeyboardAvoidingView style={styles.wrap} behavior={Platform.OS === 'ios' ? 'padding' : undefined}>
      <PhaseHeader
        eyebrow={`round ${round.round}`}
        title={isFirstRound ? "Think of any word. Don't overthink it." : 'No match yet. Find a word that connects these:'}
      />

      {!isFirstRound && (
        <View style={styles.pool}>
          {round.previousWords.map((w, i) => (
            <View key={`${w}-${i}`} style={styles.chip}>
              <Text style={styles.chipText}>{w}</Text>
            </View>
          ))}
        </View>
      )}

      <SyncRing players={players} showStatus centerLabel={`${readyCount}/${players.length}`} />

      <View style={styles.form}>
        <TextInput
          value={word}
          onChangeText={setWord}
          editable={!lockedIn}
          placeholder={isFirstRound ? 'Type your word…' : 'Find the middle ground…'}
          placeholderTextColor={colors.dim}
          maxLength={40}
          autoCapitalize="none"
          autoCorrect={false}
          onSubmitEditing={handleSubmit}
          style={[styles.input, lockedIn && styles.inputDisabled]}
        />
        <PrimaryButton label="Lock in" onPress={handleSubmit} disabled={!word.trim() || lockedIn} />
        {lockedIn && <Text style={styles.lockedMsg}>Locked in. Waiting on the rest of the group…</Text>}
      </View>
    </KeyboardAvoidingView>
  );
}

const styles = StyleSheet.create({
  wrap: { flex: 1, backgroundColor: colors.bg, paddingHorizontal: 24, paddingTop: 60, alignItems: 'center' },
  pool: { flexDirection: 'row', flexWrap: 'wrap', justifyContent: 'center', gap: 8, marginBottom: 8 },
  chip: {
    borderWidth: 1,
    borderColor: 'rgba(255,180,84,0.4)',
    backgroundColor: 'rgba(255,180,84,0.08)',
    borderRadius: radii.pill,
    paddingHorizontal: 10,
    paddingVertical: 5,
    marginBottom: 4,
  },
  chipText: { fontFamily: fonts.mono, fontSize: 12, color: colors.amber },
  form: { width: '100%', maxWidth: 340, gap: 10, marginTop: 8 },
  input: {
    backgroundColor: colors.surface,
    borderWidth: 1,
    borderColor: colors.line,
    borderRadius: radii.sm,
    color: colors.text,
    fontFamily: fonts.body,
    fontSize: 16,
    paddingHorizontal: 16,
    paddingVertical: 14,
  },
  inputDisabled: { opacity: 0.5 },
  lockedMsg: {
    fontFamily: fonts.mono,
    fontSize: 13,
    color: colors.amber,
    textAlign: 'center',
    marginTop: 6,
  },
});
