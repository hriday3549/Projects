import React, { useState } from 'react';
import { View, Text, StyleSheet, Pressable } from 'react-native';
import { CameraView, useCameraPermissions } from 'expo-camera';
import * as Haptics from 'expo-haptics';
import { colors, fonts, radii } from '@/theme/tokens';
import { PrimaryButton } from '@/components/PrimaryButton';
import { parseHostAddress } from '@/hooks/parseHostAddress';
import type { HostAddress } from '@/types';

interface ScannerScreenProps {
  onFound: (address: HostAddress) => void;
  onCancel: () => void;
}

export function ScannerScreen({ onFound, onCancel }: ScannerScreenProps) {
  const [permission, requestPermission] = useCameraPermissions();
  const [scanned, setScanned] = useState(false);
  const [notFoundHint, setNotFoundHint] = useState(false);

  if (!permission) {
    return <View style={styles.wrap} />;
  }

  if (!permission.granted) {
    return (
      <View style={[styles.wrap, styles.centered]}>
        <Text style={styles.title}>Camera access needed</Text>
        <Text style={styles.body}>
          Mind Meld scans the QR code on the Host's screen so you don't have to type an IP address.
        </Text>
        <PrimaryButton label="Allow camera" onPress={requestPermission} style={{ marginTop: 20, width: '100%' }} />
        <Pressable onPress={onCancel} style={{ marginTop: 14 }}>
          <Text style={styles.cancel}>Enter IP manually instead</Text>
        </Pressable>
      </View>
    );
  }

  const handleScanned = ({ data }: { data: string }) => {
    if (scanned) return;
    const address = parseHostAddress(data);
    if (!address) {
      setNotFoundHint(true);
      return;
    }
    setScanned(true);
    Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success).catch(() => {});
    onFound(address);
  };

  return (
    <View style={styles.wrap}>
      <CameraView
        style={StyleSheet.absoluteFillObject}
        facing="back"
        barcodeScannerSettings={{ barcodeTypes: ['qr'] }}
        onBarcodeScanned={scanned ? undefined : handleScanned}
      />
      <View style={styles.overlay}>
        <View style={styles.frame} />
        <Text style={styles.hint}>
          {notFoundHint
            ? "That QR isn't a Mind Meld join code — point at the Host's Lobby screen."
            : "Point your camera at the Host's Lobby QR code"}
        </Text>
        <Pressable onPress={onCancel} style={styles.cancelBtn}>
          <Text style={styles.cancel}>Enter IP manually instead</Text>
        </Pressable>
      </View>
    </View>
  );
}

const FRAME_SIZE = 240;

const styles = StyleSheet.create({
  wrap: { flex: 1, backgroundColor: colors.bg },
  centered: { alignItems: 'center', justifyContent: 'center', padding: 24 },
  title: {
    fontFamily: fonts.display,
    fontWeight: '700',
    fontSize: 20,
    color: colors.text,
    marginBottom: 10,
    textAlign: 'center',
  },
  body: { fontFamily: fonts.body, fontSize: 14, color: colors.dim, textAlign: 'center', lineHeight: 20 },
  overlay: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: 'rgba(16,14,27,0.35)',
    paddingHorizontal: 24,
  },
  frame: {
    width: FRAME_SIZE,
    height: FRAME_SIZE,
    borderRadius: radii.lg,
    borderWidth: 2,
    borderColor: colors.violet,
    marginBottom: 24,
  },
  hint: {
    fontFamily: fonts.mono,
    fontSize: 13,
    color: colors.text,
    textAlign: 'center',
    backgroundColor: 'rgba(27,24,48,0.85)',
    paddingHorizontal: 16,
    paddingVertical: 10,
    borderRadius: radii.pill,
    overflow: 'hidden',
  },
  cancelBtn: { marginTop: 22 },
  cancel: { fontFamily: fonts.body, fontSize: 13, color: colors.violet, textDecorationLine: 'underline' },
});
